﻿using System;
namespace zad7
{
    public interface ICommand
    {
        void Execute();
    }
}
