﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zad2
{
    interface ICleaning
    {
        int CleanAnimals();
        bool IsClean { get; set; }
    }
}
