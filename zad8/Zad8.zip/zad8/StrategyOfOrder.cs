﻿using System;

//class which has definied methods needed for all algorithms

namespace zad8
{
    public abstract class StrategyOfOrder
    {
        public abstract void Restaurant();
    }
}
