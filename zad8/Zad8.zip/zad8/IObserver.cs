﻿using System;
namespace zad8
{
    public interface IObserver
    {
        void Update();
    }
}
