﻿using System;
namespace zad6

    // interface IEmployee (prepared for composite)

{
    public interface IEmployee
    {
        public void DisplayEmployeeInfo();
    }
}
