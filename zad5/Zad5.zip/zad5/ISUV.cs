﻿using System;
namespace zad5
{
    public interface ISUV
    {
        string SUV();
        double Price { get; }
    }
}
