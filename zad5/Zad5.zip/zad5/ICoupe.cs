﻿using System;
namespace zad5
{
    public interface ICoupe
    {
        string Coupe();
        double Price { get;}
    }
}
