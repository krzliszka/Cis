﻿using System;
namespace zad5
{
    public class Client
    {
       
    }
}
