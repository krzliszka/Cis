﻿using System;
namespace zad5
{
    public interface ISedan
    {
        string Sedan();
        double Price { get; }
        //string Function(ISUV c);
    }
}
